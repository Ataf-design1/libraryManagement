import React from 'react'
import AddBookForm from './components/AddBookForm'
import BookList from './components/Booklist'

const App = () => {
  return (
    <div className="bg-gray-100 min-h-screen p-8">
      <h1 className="text-3xl font-bold text-center mb-8">Library Management Dashboard</h1>
      <AddBookForm />
      <BookList />
    </div>
  )
}

export default App