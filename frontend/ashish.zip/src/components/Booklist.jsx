
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Loader from './Loader';
import Error from './Error';
import Success from './Success';
import { deleteBook, getBooks } from '../redux/action';

const BookList = () => {
  const dispatch = useDispatch();

  // Access Redux state
  const { books, loading, error, success } = useSelector(state => state);

  useEffect(() => {
    dispatch(getBooks());
  }, [dispatch]);

  const handleDelete = (id) => {
    dispatch(deleteBook(id));
  };

  return (
    <div className="container mx-auto p-4">
      {loading && <Loader />}
      {error && <Error message={error} />}
      {success && <Success message="Action was successful!" />}
      
      <h2 className="text-2xl font-bold mb-4">Book List</h2>
      <table className="min-w-full table-auto">
        <thead>
          <tr>
            <th className="px-4 py-2">Title</th>
            <th className="px-4 py-2">Author</th>
            <th className="px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {books && books.map((book) => (
            <tr key={book._id}>
              <td className="px-4 py-2">{book.title}</td>
              <td className="px-4 py-2">{book.author}</td>
              <td className="px-4 py-2">
                <button 
                  className="bg-blue-500 text-white px-4 py-2 rounded mr-2"
                  onClick={() => alert('Edit functionality will be here')}>
                  Edit
                </button>
                <button
                  className="bg-red-500 text-white px-4 py-2 rounded"
                  onClick={() => handleDelete(book._id)}>
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default BookList;
